
# THIS FILE IS GENERATED FROM SLYCOT SETUP.PY
short_version = '0.3.5'
version = '0.3.5'
full_version = '0.3.5'
git_revision = '003a2afe09987d80e45302bd3534eb530653f542'
release = True

if not release:
    version = full_version
